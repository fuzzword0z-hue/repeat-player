package com.myrepeat.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import org.json.JSONArray
import org.json.JSONObject

/**
 * 마지막으로 듣던 폴더, 곡, 회차, 재생 위치를 기기에 저장해 두고
 * 앱이 꺼졌다 다시 켜지면 그 상태 그대로 불러온다.
 */
object ResumeStore {

    private const val PREFS = "resume"
    private const val KEY_QUEUE = "queue"
    private const val KEY_SONG = "song"
    private const val KEY_COPY = "copy"
    private const val KEY_POSITION = "position"

    class Saved(val items: List<MediaItem>, val startIndex: Int, val positionMs: Long)

    /** 재생 목록이 바뀌었을 때: 폴더 이름, 곡 목록, 반복 횟수를 저장한다. */
    fun saveQueue(context: Context, player: Player) {
        val count = player.mediaItemCount
        if (count == 0) return
        val key = QueueKey.parse(player.getMediaItemAt(0).mediaId) ?: return
        val first = player.getMediaItemAt(0)
        val songs = JSONArray()
        for (i in 0 until count step key.repeatCount) {
            val ref = PlayQueue.songRefOf(player.getMediaItemAt(i)) ?: continue
            songs.put(
                JSONObject()
                    .put("id", ref.mediaStoreId)
                    .put("uri", ref.uri.toString())
                    .put("title", ref.title)
                    .put("artist", ref.artist)
            )
        }
        val json = JSONObject()
            .put("category", first.mediaMetadata.albumTitle?.toString().orEmpty())
            .put("repeat", key.repeatCount)
            .put("songs", songs)
        prefs(context).edit().putString(KEY_QUEUE, json.toString()).apply()
        savePosition(context, player)
    }

    /** 지금 몇 번째 곡의 몇 번째 회차, 몇 초 지점인지 저장한다. */
    fun savePosition(context: Context, player: Player, now: Boolean = false) {
        val key = QueueKey.parse(player.currentMediaItem?.mediaId) ?: return
        val editor = prefs(context).edit()
            .putInt(KEY_SONG, key.song)
            .putInt(KEY_COPY, key.copy)
            .putLong(KEY_POSITION, player.currentPosition.coerceAtLeast(0L))
        if (now) editor.commit() else editor.apply()
    }

    /** 저장해 둔 상태로 재생 목록을 다시 만든다. 저장된 것이 없으면 null. */
    fun load(context: Context): Saved? = runCatching {
        val p = prefs(context)
        val json = JSONObject(p.getString(KEY_QUEUE, null) ?: return null)
        val repeat = json.getInt("repeat").coerceAtLeast(1)
        val arr = json.getJSONArray("songs")
        val refs = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SongRef(
                mediaStoreId = o.getLong("id"),
                uri = Uri.parse(o.getString("uri")),
                title = o.optString("title"),
                artist = o.optString("artist"),
            )
        }
        if (refs.isEmpty()) return null
        val song = p.getInt(KEY_SONG, 0).coerceIn(0, refs.size - 1)
        val copy = p.getInt(KEY_COPY, 0).coerceIn(0, repeat - 1)
        Saved(
            items = PlayQueue.build(json.optString("category"), refs, repeat),
            startIndex = QueueMath.indexFor(song, copy, repeat),
            positionMs = p.getLong(KEY_POSITION, 0L).coerceAtLeast(0L),
        )
    }.getOrNull()

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
