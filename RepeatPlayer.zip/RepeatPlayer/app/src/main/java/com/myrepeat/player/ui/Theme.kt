package com.myrepeat.player.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 공부 노트 느낌: 잉크 파랑 + 형광펜 노랑(반복 표시)
private val LightColors = lightColorScheme(
    primary = Color(0xFF24467A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD8E3F4),
    onPrimaryContainer = Color(0xFF0E2448),
    secondary = Color(0xFFE0AC12),
    onSecondary = Color(0xFF2A2100),
    background = Color(0xFFEDF1F5),
    onBackground = Color(0xFF172131),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF172131),
    surfaceVariant = Color(0xFFE2E8EF),
    onSurfaceVariant = Color(0xFF5A6577),
    outline = Color(0xFFC6CEDA),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA9C3F0),
    onPrimary = Color(0xFF0D244A),
    primaryContainer = Color(0xFF263A5C),
    onPrimaryContainer = Color(0xFFD8E3F4),
    secondary = Color(0xFFF2CF4E),
    onSecondary = Color(0xFF2A2100),
    background = Color(0xFF10161F),
    onBackground = Color(0xFFE4E8EE),
    surface = Color(0xFF18212D),
    onSurface = Color(0xFFE4E8EE),
    surfaceVariant = Color(0xFF222C39),
    onSurfaceVariant = Color(0xFF9AA5B5),
    outline = Color(0xFF34404F),
)

@Composable
fun RepeatPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
