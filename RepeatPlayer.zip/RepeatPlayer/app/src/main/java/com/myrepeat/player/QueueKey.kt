package com.myrepeat.player

/**
 * 재생 큐는 "곡 × 반복 횟수" 만큼 같은 곡을 연달아 넣어 만든다.
 * 예) 3번 반복이면 [1번곡, 1번곡, 1번곡, 2번곡, 2번곡, 2번곡, ...]
 * 각 항목의 mediaId에 "몇 번째 곡의 몇 번째 반복인지"를 적어 둔다.
 */
data class QueueKey(
    val song: Int,
    val copy: Int,
    val repeatCount: Int,
    val mediaStoreId: Long,
) {
    fun encode(): String = "rp|$song|$copy|$repeatCount|$mediaStoreId"

    companion object {
        fun parse(mediaId: String?): QueueKey? {
            if (mediaId == null) return null
            val parts = mediaId.split('|')
            if (parts.size != 5 || parts[0] != "rp") return null
            val song = parts[1].toIntOrNull() ?: return null
            val copy = parts[2].toIntOrNull() ?: return null
            val repeatCount = parts[3].toIntOrNull() ?: return null
            val id = parts[4].toLongOrNull() ?: return null
            if (song < 0 || repeatCount < 1 || copy !in 0 until repeatCount) return null
            return QueueKey(song, copy, repeatCount, id)
        }
    }
}

object QueueMath {
    /** 곡 번호와 반복 회차로 큐 위치를 계산한다. */
    fun indexFor(song: Int, copy: Int, repeatCount: Int): Int {
        val n = repeatCount.coerceAtLeast(1)
        return song * n + copy.coerceIn(0, n - 1)
    }

    /**
     * 지금 위치에서 다음 곡(+1) 또는 이전 곡(-1)의 첫 번째 반복 위치.
     * 마지막 곡 다음은 첫 곡, 첫 곡 이전은 마지막 곡으로 돈다.
     */
    fun songJumpTarget(currentIndex: Int, itemCount: Int, repeatCount: Int, direction: Int): Int {
        if (itemCount <= 0) return 0
        val n = repeatCount.coerceAtLeast(1)
        val songCount = (itemCount / n).coerceAtLeast(1)
        val song = (currentIndex / n).coerceIn(0, songCount - 1)
        return (song + direction).mod(songCount) * n
    }
}
