package com.myrepeat.player

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class SongRef(
    val mediaStoreId: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
)

object PlayQueue {

    /** 각 곡을 repeatCount번씩 연달아 넣은 재생 큐를 만든다. */
    fun build(categoryName: String, songs: List<SongRef>, repeatCount: Int): List<MediaItem> {
        val items = ArrayList<MediaItem>(songs.size * repeatCount)
        songs.forEachIndexed { songIndex, song ->
            val metadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(categoryName)
                .build()
            // 앱 화면에서 서비스로 넘어갈 때 주소(uri)를 잃지 않도록 requestMetadata에도 담는다.
            val request = MediaItem.RequestMetadata.Builder().setMediaUri(song.uri).build()
            for (copy in 0 until repeatCount) {
                items.add(
                    MediaItem.Builder()
                        .setMediaId(QueueKey(songIndex, copy, repeatCount, song.mediaStoreId).encode())
                        .setUri(song.uri)
                        .setRequestMetadata(request)
                        .setMediaMetadata(metadata)
                        .build()
                )
            }
        }
        return items
    }

    /** 큐 항목에서 원래 곡 정보를 되찾는다(반복 횟수를 바꿔 큐를 다시 만들 때 사용). */
    fun songRefOf(item: MediaItem): SongRef? {
        val key = QueueKey.parse(item.mediaId) ?: return null
        val uri = item.requestMetadata.mediaUri ?: item.localConfiguration?.uri ?: return null
        return SongRef(
            mediaStoreId = key.mediaStoreId,
            uri = uri,
            title = item.mediaMetadata.title?.toString().orEmpty(),
            artist = item.mediaMetadata.artist?.toString().orEmpty(),
        )
    }
}
