package com.myrepeat.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val fileName: String,
    val folderPath: String,
    val durationMs: Long,
) {
    fun toRef() = SongRef(id, uri, title, artist)
}

enum class Grouping { FOLDER, ALBUM }

data class Category(
    val key: String,
    val name: String,
    val detail: String,
    val songs: List<Song>,
)

object MediaLibrary {

    @Suppress("DEPRECATION") // DATA(파일 경로)는 폴더 이름을 알아내는 데만 쓴다.
    fun loadSongs(context: Context): List<Song> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
        )
        // 벨소리·알림음·알람음은 뺀다.
        val selection = listOf(
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
        ).joinToString(" AND ") { "($it IS NULL OR $it = 0)" }

        val songs = ArrayList<Song>()
        context.contentResolver.query(collection, projection, selection, null, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val fileName: String = c.getString(nameCol) ?: ""
                val path: String = c.getString(dataCol) ?: ""
                val rawTitle: String? = c.getString(titleCol)
                val rawArtist: String? = c.getString(artistCol)
                songs += Song(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    title = if (rawTitle.isNullOrBlank()) fileName.substringBeforeLast('.') else rawTitle,
                    artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "" else rawArtist,
                    album = c.getString(albumCol) ?: "",
                    albumId = c.getLong(albumIdCol),
                    fileName = fileName,
                    folderPath = path.substringBeforeLast('/', missingDelimiterValue = ""),
                    durationMs = c.getLong(durationCol),
                )
            }
        }
        return songs
    }

    /** 폴더별 또는 앨범별로 묶고, 각 묶음 안의 곡은 파일 이름 순서(숫자 크기 순)로 정렬한다. */
    fun group(songs: List<Song>, grouping: Grouping): List<Category> {
        val byFileName = compareBy<Song, String>(NaturalOrder) { it.fileName }
        val categories = when (grouping) {
            Grouping.FOLDER -> songs.groupBy { it.folderPath }.map { (path, list) ->
                Category(
                    key = "folder:$path",
                    name = path.substringAfterLast('/').ifBlank { "기타" },
                    detail = shortPath(path),
                    songs = list.sortedWith(byFileName),
                )
            }
            Grouping.ALBUM -> songs.groupBy { it.albumId }.map { (albumId, list) ->
                val sorted = list.sortedWith(byFileName)
                Category(
                    key = "album:$albumId",
                    name = sorted.first().album.ifBlank { "앨범 정보 없음" },
                    detail = sorted.first().artist,
                    songs = sorted,
                )
            }
        }
        return categories.sortedWith(compareBy<Category, String>(NaturalOrder) { it.name })
    }

    private fun shortPath(path: String): String =
        path.removePrefix("/storage/emulated/0").trimStart('/')
}
