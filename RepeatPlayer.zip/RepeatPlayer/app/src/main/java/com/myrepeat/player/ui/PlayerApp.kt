package com.myrepeat.player.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import com.myrepeat.player.Category
import com.myrepeat.player.Grouping
import com.myrepeat.player.MediaLibrary
import com.myrepeat.player.PlayQueue
import com.myrepeat.player.QueueKey
import com.myrepeat.player.QueueMath
import com.myrepeat.player.R
import com.myrepeat.player.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val PREFS = "settings"
private const val KEY_REPEAT = "repeat_count"
private const val MIN_REPEAT = 1
private const val MAX_REPEAT = 99

/** 화면에 보여 줄 재생 상태. 서비스의 플레이어에서 읽어 온다. */
@Stable
class PlayerUi {
    var hasMedia by mutableStateOf(false)
    var playWhenReady by mutableStateOf(false)
    var title by mutableStateOf("")
    var category by mutableStateOf("")
    var songIndex by mutableIntStateOf(0)
    var songCount by mutableIntStateOf(0)
    var copy by mutableIntStateOf(0)
    var repeatCount by mutableIntStateOf(0)
    var mediaStoreId by mutableLongStateOf(-1L)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)

    fun sync(player: Player) {
        val item = player.currentMediaItem
        val key = QueueKey.parse(item?.mediaId)
        hasMedia = item != null && key != null
        playWhenReady = player.playWhenReady
        title = item?.mediaMetadata?.title?.toString().orEmpty()
        category = item?.mediaMetadata?.albumTitle?.toString().orEmpty()
        songIndex = key?.song ?: 0
        copy = key?.copy ?: 0
        repeatCount = key?.repeatCount ?: 0
        songCount = if (key != null) player.mediaItemCount / key.repeatCount else 0
        mediaStoreId = key?.mediaStoreId ?: -1L
        updateProgress(player)
    }

    fun updateProgress(player: Player) {
        positionMs = player.currentPosition.coerceAtLeast(0L)
        durationMs = player.duration.coerceAtLeast(0L)
    }
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

@Composable
fun RepeatPlayerApp(controller: MediaController?) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var repeatChoice by remember {
        mutableIntStateOf(prefs.getInt(KEY_REPEAT, 3).coerceIn(MIN_REPEAT, MAX_REPEAT))
    }

    // 권한
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> granted = ok }

    // 기기의 오디오 파일 목록
    var songs by remember { mutableStateOf<List<Song>?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(granted, reloadTick) {
        if (!granted) return@LaunchedEffect
        songs = null
        songs = withContext(Dispatchers.IO) {
            runCatching { MediaLibrary.loadSongs(context) }.getOrDefault(emptyList())
        }
    }

    // 지금은 폴더별로만 보여 준다. (앨범별 묶기 코드는 MediaLibrary에 남아 있다)
    val grouping = Grouping.FOLDER
    var openKey by rememberSaveable { mutableStateOf<String?>(null) }
    val loaded = songs
    val categories = remember(loaded, grouping) {
        if (loaded == null) emptyList() else MediaLibrary.group(loaded, grouping)
    }
    val openCategory = categories.firstOrNull { it.key == openKey }

    // 재생 상태 따라가기
    val ui = remember { PlayerUi() }
    DisposableEffect(controller) {
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                ui.sync(player)
            }
        }
        controller?.addListener(listener)
        controller?.let { ui.sync(it) }
        onDispose { controller?.removeListener(listener) }
    }
    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        while (true) {
            ui.updateProgress(c)
            delay(500)
        }
    }

    fun playCategory(category: Category, startSong: Int) {
        val c = controller ?: return
        val n = repeatChoice
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_ALL
        c.setMediaItems(
            PlayQueue.build(category.name, category.songs.map { it.toRef() }, n),
            QueueMath.indexFor(startSong, 0, n),
            0L,
        )
        c.prepare()
        c.play()
    }

    fun changeRepeat(value: Int) {
        val n = value.coerceIn(MIN_REPEAT, MAX_REPEAT)
        if (n == repeatChoice) return
        repeatChoice = n
        prefs.edit().putInt(KEY_REPEAT, n).apply()
        // 재생 중이면 지금 곡·위치를 유지한 채 큐를 새 횟수로 다시 만든다.
        val c = controller ?: return
        val key = QueueKey.parse(c.currentMediaItem?.mediaId) ?: return
        if (key.repeatCount == n) return
        val refs = (0 until c.mediaItemCount step key.repeatCount)
            .mapNotNull { PlayQueue.songRefOf(c.getMediaItemAt(it)) }
        if (refs.isEmpty()) return
        val categoryName = c.currentMediaItem?.mediaMetadata?.albumTitle?.toString().orEmpty()
        val position = c.currentPosition
        c.setMediaItems(
            PlayQueue.build(categoryName, refs, n),
            QueueMath.indexFor(key.song, key.copy, n),
            position,
        )
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.playWhenReady) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun stop() {
        val c = controller ?: return
        c.pause()
        val key = QueueKey.parse(c.currentMediaItem?.mediaId)
        if (key != null) {
            c.seekTo(QueueMath.indexFor(key.song, 0, key.repeatCount), 0L)
        } else {
            c.seekTo(0L)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        if (openCategory != null) {
            Header(
                title = openCategory.name,
                subtitle = "${openCategory.songs.size}곡, 곡마다 ${repeatChoice}번씩 듣고 다음 곡으로",
                onBack = { openKey = null },
            )
        } else {
            Header(
                title = "반복 플레이어",
                subtitle = "폴더를 고르면 전곡을 끝없이 반복해요",
                onRefresh = if (granted) ({ reloadTick += 1 }) else null,
            )
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when {
                !granted -> PermissionPane(
                    onRequest = {
                        if (hasAudioPermission(context)) {
                            granted = true
                        } else {
                            permissionLauncher.launch(audioPermission())
                        }
                    },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null),
                            )
                        )
                    },
                )

                loaded == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }

                openCategory != null -> SongList(
                    category = openCategory,
                    playingId = ui.mediaStoreId,
                    repeatCount = repeatChoice,
                    enabled = controller != null,
                    onPlay = { index -> playCategory(openCategory, index) },
                )

                else -> CategoryList(
                    categories = categories,
                    grouping = grouping,
                    playingId = ui.mediaStoreId,
                    onOpen = { openKey = it.key },
                )
            }
        }

        PlayerPanel(
            ui = ui,
            repeatChoice = repeatChoice,
            active = controller != null && ui.hasMedia,
            onRepeatChange = { changeRepeat(it) },
            onPrevious = { controller?.seekToPrevious() },
            onStop = { stop() },
            onToggle = { togglePlay() },
            onNext = { controller?.seekToNext() },
            onSeek = { controller?.seekTo(it) },
        )
    }

    BackHandler(enabled = openCategory != null) { openKey = null }
}

@Composable
private fun Header(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)? = null,
    onRefresh: (() -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(painterResource(R.drawable.ic_back), contentDescription = "뒤로")
            }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onRefresh != null) {
            TextButton(onClick = onRefresh) { Text("새로고침") }
        }
    }
}

/** 둘 중 하나를 고르는 알약 모양 버튼. */
@Composable
private fun <T> Segmented(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(50)
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier
            .clip(shape)
            .border(1.dp, scheme.outline, shape)
            .padding(3.dp)
    ) {
        options.forEach { (value, label) ->
            val active = value == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(if (active) scheme.primary else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (active) scheme.onPrimary else scheme.onSurface,
                )
            }
        }
    }
}

@Composable
private fun PermissionPane(onRequest: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "음악 파일 접근을 허용해 주세요",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "기기에 있는 오디오 파일을 폴더별로 불러오는 데 필요해요.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRequest) { Text("접근 허용") }
        TextButton(onClick = onOpenSettings) { Text("설정에서 직접 허용하기") }
    }
}

@Composable
private fun EmptyPane(message: String) {
    Box(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            message,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CategoryList(
    categories: List<Category>,
    grouping: Grouping,
    playingId: Long,
    onOpen: (Category) -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        if (categories.isEmpty()) {
            EmptyPane("기기에서 오디오 파일을 찾지 못했어요. 파일을 넣은 뒤 새로고침을 눌러 주세요.")
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(categories, key = { it.key }) { category ->
                    CategoryRow(
                        category = category,
                        grouping = grouping,
                        isCurrent = category.songs.any { it.id == playingId },
                        onClick = { onOpen(category) },
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryRow(
    category: Category,
    grouping: Grouping,
    isCurrent: Boolean,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isCurrent) scheme.secondary else scheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painterResource(if (grouping == Grouping.FOLDER) R.drawable.ic_folder else R.drawable.ic_note),
                contentDescription = null,
                tint = if (isCurrent) scheme.onSecondary else scheme.onPrimaryContainer,
                modifier = Modifier.size(22.dp),
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                category.name,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${category.songs.size}곡",
                    style = MaterialTheme.typography.labelMedium,
                    color = scheme.primary,
                )
                if (category.detail.isNotBlank()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        category.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (isCurrent) {
            Spacer(Modifier.width(8.dp))
            Text("재생 중", style = MaterialTheme.typography.labelMedium, color = scheme.primary)
        }
    }
}

@Composable
private fun SongList(
    category: Category,
    playingId: Long,
    repeatCount: Int,
    enabled: Boolean,
    onPlay: (Int) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
    ) {
        item(key = "play-all") {
            Button(
                onClick = { onPlay(0) },
                enabled = enabled,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
            ) {
                Icon(
                    painterResource(R.drawable.ic_repeat),
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("첫 곡부터 반복 재생 (곡마다 ${repeatCount}번)")
            }
        }
        itemsIndexed(category.songs, key = { _, song -> song.id }) { index, song ->
            val current = song.id == playingId
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (current) scheme.primaryContainer else Color.Transparent)
                    .clickable(enabled = enabled) { onPlay(index) }
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    (index + 1).toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (current) scheme.primary else scheme.onSurfaceVariant,
                    modifier = Modifier.width(36.dp),
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (current) FontWeight.SemiBold else null,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        song.fileName,
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    formatTime(song.durationMs),
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun PlayerPanel(
    ui: PlayerUi,
    repeatChoice: Int,
    active: Boolean,
    onRepeatChange: (Int) -> Unit,
    onPrevious: () -> Unit,
    onStop: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(scheme.surface)
            .navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 10.dp),
    ) {
        if (ui.hasMedia) {
            Text(
                ui.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                ui.category,
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RepeatDots(current = ui.copy, total = ui.repeatCount)
                Spacer(Modifier.width(10.dp))
                Text(
                    "${ui.repeatCount}번 중 ${ui.copy + 1}번째 듣는 중",
                    style = MaterialTheme.typography.labelLarge,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "${ui.songIndex + 1} / ${ui.songCount}곡",
                    style = MaterialTheme.typography.labelMedium,
                    color = scheme.onSurfaceVariant,
                )
            }
        } else {
            Text("재생 중인 곡이 없어요", style = MaterialTheme.typography.titleMedium)
            Text(
                "폴더를 열고 곡을 누르면 시작해요",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
            )
        }

        // 재생 위치 (끌어서 이동)
        var dragFraction by remember { mutableStateOf<Float?>(null) }
        val duration = ui.durationMs
        val fraction = if (duration > 0) (ui.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
        Slider(
            value = dragFraction ?: fraction,
            onValueChange = { dragFraction = it },
            onValueChangeFinished = {
                dragFraction?.let { onSeek((it * duration).toLong()) }
                dragFraction = null
            },
            enabled = active && duration > 0,
            modifier = Modifier.padding(top = 4.dp),
        )
        Row(Modifier.fillMaxWidth()) {
            val shown = dragFraction?.let { (it * duration).toLong() } ?: ui.positionMs
            Text(formatTime(shown), style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
        }

        // 이전 / 정지 / 재생·일시정지 / 다음
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                ControlButton(R.drawable.ic_prev, "이전 곡", active, onPrevious)
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                ControlButton(R.drawable.ic_stop, "정지", active, onStop)
            }
            Box(Modifier.weight(1.3f), contentAlignment = Alignment.Center) {
                PlayButton(playing = ui.playWhenReady, enabled = active, onClick = onToggle)
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                ControlButton(R.drawable.ic_next, "다음 곡", active, onNext)
            }
        }

        // 한 곡당 반복 횟수
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "한 곡당",
                style = MaterialTheme.typography.labelLarge,
                color = scheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(8.dp))
            RepeatStepper(value = repeatChoice, onChange = onRepeatChange)
            Spacer(Modifier.weight(1f))
            Icon(
                painterResource(R.drawable.ic_repeat),
                contentDescription = null,
                tint = scheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text("전곡 반복", style = MaterialTheme.typography.labelMedium, color = scheme.primary)
        }
    }
}

/** 반복 횟수를 [-] N번 [+] 로 바꾸고, 숫자를 누르면 직접 입력한다. */
@Composable
private fun RepeatStepper(value: Int, onChange: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    var editing by remember { mutableStateOf(false) }
    Row(
        Modifier
            .clip(shape)
            .border(1.dp, scheme.outline, shape),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StepButton("−", "한 번 줄이기", enabled = value > MIN_REPEAT) { onChange(value - 1) }
        Box(
            Modifier
                .width(56.dp)
                .clickable { editing = true }
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "${value}번",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = scheme.primary,
            )
        }
        StepButton("+", "한 번 늘리기", enabled = value < MAX_REPEAT) { onChange(value + 1) }
    }
    if (editing) {
        RepeatInputDialog(
            initial = value,
            onDismiss = { editing = false },
            onConfirm = {
                editing = false
                onChange(it)
            },
        )
    }
}

@Composable
private fun StepButton(symbol: String, label: String, enabled: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            symbol,
            style = MaterialTheme.typography.titleLarge,
            color = if (enabled) scheme.onSurface else scheme.outline,
            modifier = Modifier.semantics { contentDescription = label },
        )
    }
}

@Composable
private fun RepeatInputDialog(initial: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var text by remember { mutableStateOf(initial.toString()) }
    val number = text.toIntOrNull()
    val valid = number != null && number in MIN_REPEAT..MAX_REPEAT
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("한 곡당 반복 횟수") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { new -> text = new.filter { it.isDigit() }.take(2) },
                singleLine = true,
                isError = text.isNotEmpty() && !valid,
                suffix = { Text("번") },
                supportingText = { Text("${MIN_REPEAT}~${MAX_REPEAT} 사이 숫자") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = { number?.let(onConfirm) }, enabled = valid) { Text("확인") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("취소") }
        },
    )
}

/** 지금 몇 번째 반복인지 형광펜 점으로 보여 준다. ●●○ = 3번 중 2번째 */
@Composable
private fun RepeatDots(current: Int, total: Int) {
    // 횟수가 많으면 점이 넘치므로 점은 10개까지만 보여 준다(글자로 횟수를 함께 보여 줌).
    if (total > 10) return
    val scheme = MaterialTheme.colorScheme
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until total) {
            Box(
                Modifier
                    .size(if (i == current) 12.dp else 9.dp)
                    .clip(CircleShape)
                    .background(if (i <= current) scheme.secondary else scheme.outline)
            )
        }
    }
}

@Composable
private fun ControlButton(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(52.dp)) {
        Icon(painterResource(icon), contentDescription = label, modifier = Modifier.size(30.dp))
    }
}

@Composable
private fun PlayButton(playing: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(if (enabled) scheme.primary else scheme.outline)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play),
            contentDescription = if (playing) "일시정지" else "재생",
            tint = scheme.onPrimary,
            modifier = Modifier.size(34.dp),
        )
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSeconds = ms / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
