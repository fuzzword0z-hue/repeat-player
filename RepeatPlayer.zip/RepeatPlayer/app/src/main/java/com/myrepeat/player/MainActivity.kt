package com.myrepeat.player

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.myrepeat.player.ui.RepeatPlayerApp
import com.myrepeat.player.ui.RepeatPlayerTheme

class MainActivity : ComponentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controller = mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RepeatPlayerTheme {
                RepeatPlayerApp(controller = controller.value)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // 화면이 보일 때 재생 서비스에 연결한다.
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                if (controllerFuture === future) {
                    controller.value = runCatching { future.get() }.getOrNull()
                }
            },
            ContextCompat.getMainExecutor(this),
        )
    }

    override fun onStop() {
        // 화면을 떠나도 서비스는 계속 재생한다. 연결만 끊는다.
        controller.value = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }
}
