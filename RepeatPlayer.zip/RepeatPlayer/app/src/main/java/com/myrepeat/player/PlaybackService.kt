package com.myrepeat.player

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Timeline
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * 화면이 꺼져도 재생을 이어 가는 백그라운드 서비스.
 * 알림창·잠금화면·이어폰 버튼 조작도 여기서 처리된다.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    // 재생 중에는 5초마다 위치를 저장한다. (앱이 갑자기 꺼져도 거의 같은 곳에서 이어 듣기)
    private val handler = Handler(Looper.getMainLooper())
    private val savePositionTick = object : Runnable {
        override fun run() {
            mediaSession?.player?.let { ResumeStore.savePosition(this@PlaybackService, it) }
            handler.postDelayed(this, SAVE_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()

        val exoPlayer = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true, // 전화가 오거나 다른 앱이 소리를 내면 잠시 멈춤
            )
            .setHandleAudioBecomingNoisy(true) // 이어폰을 빼면 일시정지
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // 카테고리 전체를 끝없이 반복한다. (곡별 반복은 큐에 같은 곡을 여러 번 넣어 처리)
        exoPlayer.repeatMode = Player.REPEAT_MODE_ALL

        val player = SongNavigatingPlayer(exoPlayer)
        exoPlayer.addListener(SkipBrokenFiles(exoPlayer, player))

        // 마지막으로 듣던 곡을 불러온다. 바로 재생하지는 않고 멈춘 상태로 준비만 한다.
        ResumeStore.load(this)?.let { saved ->
            exoPlayer.setMediaItems(saved.items, saved.startIndex, saved.positionMs)
            exoPlayer.prepare()
        }
        exoPlayer.addListener(object : Player.Listener {
            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) {
                    ResumeStore.saveQueue(this@PlaybackService, exoPlayer)
                }
            }

            override fun onEvents(p: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                        Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_POSITION_DISCONTINUITY,
                    )
                ) {
                    ResumeStore.savePosition(this@PlaybackService, exoPlayer)
                }
                if (events.contains(Player.EVENT_IS_PLAYING_CHANGED)) {
                    handler.removeCallbacks(savePositionTick)
                    if (exoPlayer.isPlaying) handler.postDelayed(savePositionTick, SAVE_INTERVAL_MS)
                }
            }
        })

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        mediaSession = MediaSession.Builder(this, player)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> {
                    val resolved = mediaItems.map { item ->
                        val uri = item.requestMetadata.mediaUri
                        if (uri != null) item.buildUpon().setUri(uri).build() else item
                    }.toMutableList()
                    return Futures.immediateFuture(resolved)
                }
            })
            .setSessionActivity(openApp)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // 최근 앱 목록에서 앱을 지웠을 때, 재생 중이 아니면 서비스도 끝낸다.
        val player = mediaSession?.player
        player?.let { ResumeStore.savePosition(this, it, now = true) }
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    private companion object {
        const val SAVE_INTERVAL_MS = 5_000L
    }

    override fun onDestroy() {
        handler.removeCallbacks(savePositionTick)
        mediaSession?.run {
            ResumeStore.savePosition(this@PlaybackService, player, now = true)
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}

/**
 * 다음/이전 버튼을 "곡 단위"로 바꿔 주는 래퍼.
 * 큐에는 같은 곡이 여러 번 들어 있으므로, 그냥 다음 항목으로 가면 같은 곡이 다시 나온다.
 * 앱 버튼, 알림창, 잠금화면, 이어폰 버튼 모두 이 동작을 따른다.
 */
@androidx.annotation.OptIn(UnstableApi::class)
class SongNavigatingPlayer(player: Player) : ForwardingPlayer(player) {

    override fun seekToNext() = jumpSong(+1)

    override fun seekToNextMediaItem() = jumpSong(+1)

    override fun seekToPrevious() {
        // 곡을 3초 넘게 들었으면 지금 회차를 처음부터, 아니면 이전 곡으로.
        if (currentPosition > RESTART_THRESHOLD_MS) {
            seekTo(currentMediaItemIndex, 0L)
        } else {
            jumpSong(-1)
        }
    }

    override fun seekToPreviousMediaItem() = jumpSong(-1)

    private fun jumpSong(direction: Int) {
        val total = mediaItemCount
        if (total == 0) return
        val repeatCount = QueueKey.parse(currentMediaItem?.mediaId)?.repeatCount ?: 1
        seekTo(QueueMath.songJumpTarget(currentMediaItemIndex, total, repeatCount, direction), 0L)
    }

    private companion object {
        const val RESTART_THRESHOLD_MS = 3_000L
    }
}

/** 재생할 수 없는 파일을 만나면 멈추지 않고 다음 곡으로 넘어간다. */
private class SkipBrokenFiles(
    private val exoPlayer: ExoPlayer,
    private val navigator: Player,
) : Player.Listener {

    private var errorsInARow = 0

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) errorsInARow = 0
    }

    override fun onPlayerError(error: PlaybackException) {
        errorsInARow++
        // 모든 곡이 다 실패하면 무한히 건너뛰지 않도록 멈춘다.
        if (exoPlayer.mediaItemCount == 0 || errorsInARow > exoPlayer.mediaItemCount) return
        navigator.seekToNext()
        exoPlayer.prepare()
    }
}
